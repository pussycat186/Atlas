/**
 * Atlas Secure Fabric API Definitions
 * HTTP API contracts for Gateway and Witness services
 */
export {};
//# sourceMappingURL=api.js.map